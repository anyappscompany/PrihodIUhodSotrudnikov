package ua.com.anyapps.prihodiuhodsotrudnikov;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

public class CameraActivity extends AppCompatActivity{
    private static final String TAG = "debapp";
    private TextView tvEmployeeInitials;
    private ImageView ivEmployeePhoto;
    final int REQUEST_CODE_PHOTO = 1;
    private static final String LONG_SERVER_TIME = "LONG_SERVER_TIME";
    private  TextView tvCurrentServerTitme;

    Timer T = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        tvEmployeeInitials = findViewById(R.id.tvEmployeeInitials);
        ivEmployeePhoto = findViewById(R.id.ivEmployeePhoto);
        tvCurrentServerTitme = findViewById(R.id.tvCurrentServerTitme);

        Bundle b = getIntent().getExtras();
        int employeeId = -1; // or other values
        String employeeName = "";
        String employeeSurname = "";
        if(b != null) {
            employeeId = b.getInt("employeeId");
            employeeName = b.getString("employeeName");
            employeeSurname = b.getString("employeeSurname");
        }

        tvEmployeeInitials.setText(employeeSurname + " " + employeeName);
        //Log.d(TAG, "IDID " + employeeId + " " + employeeName + " " + employeeSurname);
        ivEmployeePhoto.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Log.v(TAG, "photo click");
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                //intent.putExtra(MediaStore.EXTRA_OUTPUT, generateFileUri(TYPE_PHOTO));
                startActivityForResult(intent, REQUEST_CODE_PHOTO);
            }
        });

        //registerReceiver(broadcastReceiver, new IntentFilter(LONG_SERVER_TIME));

        initTimer();

    }

    /*BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG, "DDDDDDDDDDDDDDDDDDD");
        }
    };*/

    @Override
    protected void onPause() {
        super.onPause();
        try{
            T.cancel();
            T = null;
        }catch (Exception ex){
            //
        }

    }



    private void initTimer(){
        if(T==null) {
            T = new Timer();
            T.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    //Log.d(TAG, "Время сервера " + TimerService.serverTime);

                    // доступ к UI
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                tvCurrentServerTitme.setText(getDate(TimerService.serverTime).toString());
                            }catch (Exception ex){
                                tvCurrentServerTitme.setText(R.string.default_server_time_text);
                            }
                        }
                    });
                }
            }, 1000, 1000);
        }
    }

    private String getDate(long time) {
        Date date = new Date(time*1000L); // *1000 is to convert seconds to milliseconds
        SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z"); // the format of your date
        //sdf.setTimeZone(TimeZone.getTimeZone("GMT+4"));

        return sdf.format(date);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        try{
            T.cancel();
            T = null;
        }catch (Exception ex){
            //
        }
    }

    private static Bitmap bitmap = null;
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        if (requestCode == REQUEST_CODE_PHOTO) {
            if (resultCode == RESULT_OK) {
                if (intent == null) {
                    Log.d(TAG, "Intent is null");
                } else {
                    Log.d(TAG, "Photo uri: " + intent.getData());
                    Bundle bndl = intent.getExtras();
                    if (bndl != null) {
                        Object obj = intent.getExtras().get("data");
                        if (obj instanceof Bitmap) {
                            bitmap = (Bitmap) obj;
                            Log.d(TAG, "bitmap " + bitmap.getWidth() + " x "
                                    + bitmap.getHeight());
                            ivEmployeePhoto.setImageBitmap(bitmap);
                        }
                    }
                }
            } else if (resultCode == RESULT_CANCELED) {
                Log.d(TAG, "Canceled");
            }
        }
    }

    @Override
    protected void onResume() {
        // показать фото после разворота
        Log.d(TAG, "CAMERA RESUME");
        initTimer();
        if(bitmap!=null){ Log.d(TAG, "Resum not null");
            ivEmployeePhoto.setImageBitmap(bitmap);
        }
        super.onResume();

    }

    public void btnSaveEmployeeClick(View view)
    {
        // выводим сообщение
        Toast.makeText(this, "Зачем вы нажали?", Toast.LENGTH_SHORT).show();
    }
}

