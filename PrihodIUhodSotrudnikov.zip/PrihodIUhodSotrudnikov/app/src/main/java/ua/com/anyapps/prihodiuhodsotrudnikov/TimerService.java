package ua.com.anyapps.prihodiuhodsotrudnikov;

import android.app.IntentService;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.Context;
import android.content.IntentFilter;
import android.os.SystemClock;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class TimerService extends IntentService {
    // TODO: Rename actions, choose action names that describe tasks that this
    // IntentService can perform, e.g. ACTION_FETCH_NEW_ITEMS
    private static final String ACTION_FOO = "ua.com.anyapps.prihodiuhodsotrudnikov.action.FOO";
    private static final String ACTION_BAZ = "ua.com.anyapps.prihodiuhodsotrudnikov.action.BAZ";

    // TODO: Rename parameters
    private static final String EXTRA_PARAM1 = "ua.com.anyapps.prihodiuhodsotrudnikov.extra.PARAM1";
    private static final String EXTRA_PARAM2 = "ua.com.anyapps.prihodiuhodsotrudnikov.extra.PARAM2";

    private static final String SERVER_TIME_RECEIVED = "SERVER_TIME_RECEIVED";
    private static final String LONG_SERVER_TIME = "LONG_SERVER_TIME";
    private static final String TAG = "debapp";

    public static Long serverTime = null;

    public static boolean activeService = true;
    public int counter = 0;



    private Context receiveContext = null;

    Timer T;
    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            receiveContext = context;
            // internet lost alert dialog method call from here...
            serverTime = Long.parseLong(intent.getStringExtra("server_time"));
            Log.d(TAG, "8888888888" + serverTime);
            try{
                T.cancel();
                T = null;
            }catch (Exception ex){
                //
            }
            T = new Timer();
            T.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    serverTime = serverTime+1;
                    counter++;
                    //Log.d(TAG, "Server Time in Sec " + serverTime);
                    if(counter>=60){
                        //
                        Log.d(TAG, "Прошла минута");
                        counter = 0;

                        /*Intent broadcastedIntent = new Intent(LONG_SERVER_TIME);
                        broadcastedIntent.putExtra("server_time2", "44444444444444444"); //Long.parseLong(serverTimeInfo.getData().getServer_time())
                        receiveContext.sendBroadcast(broadcastedIntent);*/

                    }
                }
            }, 1000, 1000);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Сервис OnCreate");
        registerReceiver(broadcastReceiver, new IntentFilter(SERVER_TIME_RECEIVED));
    }

    public TimerService() {
        super("TimerService");


        Log.d(TAG, "TimerService конструктор");
        //registerReceiver(broadcastReceiver, new IntentFilter(SERVER_TIME_RECEIVED));
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        try{
            T.cancel();
            T = null;
        }catch (Exception ex){
            //
        }
        Log.d(TAG, "Сервис отключился");
        //unregisterReceiver(broadcastReceiver);
    }

    /**
     * Starts this service to perform action Foo with the given parameters. If
     * the service is already performing a task this action will be queued.
     *
     * @see IntentService
     */
    // TODO: Customize helper method
    public static void startActionFoo(Context context, String param1, String param2) {
        Intent intent = new Intent(context, TimerService.class);
        intent.setAction(ACTION_FOO);
        intent.putExtra(EXTRA_PARAM1, param1);
        intent.putExtra(EXTRA_PARAM2, param2);
        context.startService(intent);
    }

    /**
     * Starts this service to perform action Baz with the given parameters. If
     * the service is already performing a task this action will be queued.
     *
     * @see IntentService
     */
    // TODO: Customize helper method
    public static void startActionBaz(Context context, String param1, String param2) {
        Intent intent = new Intent(context, TimerService.class);
        intent.setAction(ACTION_BAZ);
        intent.putExtra(EXTRA_PARAM1, param1);
        intent.putExtra(EXTRA_PARAM2, param2);
        context.startService(intent);
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        //SystemClock.sleep(90000);
        while(activeService){}

        if (intent != null) {
            final String action = intent.getAction();
            if (ACTION_FOO.equals(action)) {
                final String param1 = intent.getStringExtra(EXTRA_PARAM1);
                final String param2 = intent.getStringExtra(EXTRA_PARAM2);
                handleActionFoo(param1, param2);
            } else if (ACTION_BAZ.equals(action)) {
                final String param1 = intent.getStringExtra(EXTRA_PARAM1);
                final String param2 = intent.getStringExtra(EXTRA_PARAM2);
                handleActionBaz(param1, param2);
            }
        }
    }

    /**
     * Handle action Foo in the provided background thread with the provided
     * parameters.
     */
    private void handleActionFoo(String param1, String param2) {
        // TODO: Handle action Foo
        throw new UnsupportedOperationException("Not yet implemented");
    }

    /**
     * Handle action Baz in the provided background thread with the provided
     * parameters.
     */
    private void handleActionBaz(String param1, String param2) {
        // TODO: Handle action Baz
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
